# Optional: Placeholder collector — needs subscription
def collect():
    print("Historical weather requires One Call History access. Skipping.")
