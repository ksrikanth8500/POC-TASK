OPENWEATHER_API_KEY = "c4af157e9bcb318f3f4e49eec7eeb130"

DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "user": "postgres",
    "password": "u",
    "database": "poc"
}
